<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Whats on your mind, Gokul</name>
   <tag></tag>
   <elementGuidId>ed85d25a-fa04-4bde-8416-35126b57e988</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.xi81zsa.x1lkfr7t.xkjl1po.x1mzt3pk.xh8yej3.x13faqbe > span.x1lliihq.x6ikm8r.x10wlt62.x1n2onr6</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mount_0_0_/u']/div/div/div/div[3]/div/div/div/div/div/div[2]/div/div/div/div[3]/div/div[2]/div/div/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>db07e7ab-9d8a-4de8-b8ef-7ba2741fff41</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>x1lliihq x6ikm8r x10wlt62 x1n2onr6</value>
      <webElementGuid>fbd7ebe5-b41b-4876-8e27-cab6ea71a3db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>What's on your mind, Gokul?</value>
      <webElementGuid>8eba62ea-040b-4c08-b7ac-a4fdbddb6469</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mount_0_0_/u&quot;)/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1n2onr6 xat3117 xxzkxad&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1t2pt76 x1n2onr6 x1ja2u2z x10cihs4&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x78zum5 x2lah0s xl56j7k x1qjc9v5 xozqiw3 x1q0g3np x1t2pt76 x17upfok&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x78zum5 x1r8uery x1iyjqo2 xs83m0k xeuugli x1qughib x1cy8zhl xozqiw3 x1q0g3np xylbxtu x1t2pt76 xornbnt&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x78zum5 x1iyjqo2 xs83m0k xeuugli xl56j7k x1qjc9v5 xozqiw3 x1q0g3np x1iplk16 x1xfsgkm xqmdsaz x1mtsufr x1w9j1nh&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x78zum5 xdt5ytf x2lah0s x193iq5w xeuugli&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;xw7yly9 xh8yej3&quot;]/div[@class=&quot;x78zum5 x1q0g3np xl56j7k&quot;]/div[@class=&quot;x193iq5w xvue9z xq1tmr x1ceravr&quot;]/div[@class=&quot;x1yztbdb&quot;]/div[@class=&quot;x78zum5 x1n2onr6 xh8yej3&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x2bj2ny x1qpq9i9 xdney7k xu5ydu1 xt3gfkd xh8yej3 x6ikm8r x10wlt62 xquyuld&quot;]/div[@class=&quot;x6s0dn4 x78zum5 x1a02dak x1a8lsjc x1pi30zi x1swvt13 xz9dl7a&quot;]/div[@class=&quot;x1cy8zhl x78zum5 x1iyjqo2 xs83m0k xh8yej3&quot;]/div[@class=&quot;x1i10hfl x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x16tdsg8 x1hl2dhg xggy1nq x87ps6o x1lku1pv x1a2a7pz x6s0dn4 xmjcpbm x107yiy2 xv8uw2v x1tfwpuw x2g32xy x78zum5 x1q0g3np x1iyjqo2 x1nhvcw1 x1n2onr6 xt7dq6l x1ba4aug x1y1aw1k xn6708d xwib8y2 x1ye3gou&quot;]/div[@class=&quot;xi81zsa x1lkfr7t xkjl1po x1mzt3pk xh8yej3 x13faqbe&quot;]/span[@class=&quot;x1lliihq x6ikm8r x10wlt62 x1n2onr6&quot;]</value>
      <webElementGuid>04a763ef-90fc-4722-adcf-36285213c34d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mount_0_0_/u']/div/div/div/div[3]/div/div/div/div/div/div[2]/div/div/div/div[3]/div/div[2]/div/div/div/div/div/div/span</value>
      <webElementGuid>85baaec2-2186-4a3e-83d9-6f3b667219ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/div/span</value>
      <webElementGuid>48f08e4e-ba7b-4033-9101-2f364d34a2c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = concat(&quot;What&quot; , &quot;'&quot; , &quot;s on your mind, Gokul?&quot;) or . = concat(&quot;What&quot; , &quot;'&quot; , &quot;s on your mind, Gokul?&quot;))]</value>
      <webElementGuid>be4f0e88-bd09-464a-81ca-3c38ac31804b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
